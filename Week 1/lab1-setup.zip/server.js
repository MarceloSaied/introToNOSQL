var app = require('./app'); // imports app.js
app.listen(3000, function() { // starts listening on http://localhost:3000/
	console.log('listening on port 3000'); // print notification on the console
});
